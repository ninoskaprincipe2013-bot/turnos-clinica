import express from "express";
import Database from "better-sqlite3";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const clients = new Set();

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const db = new Database(path.join(__dirname, "turnos.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS doctors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  number INTEGER NOT NULL,
  patient TEXT NOT NULL,
  doctor_id INTEGER NOT NULL,
  room_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'waiting',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  called_at TEXT
);
`);

if (!db.prepare("SELECT COUNT(*) c FROM doctors").get().c) {
  db.prepare("INSERT INTO doctors (name) VALUES (?)").run("Dr. Carlos García");
  db.prepare("INSERT INTO doctors (name) VALUES (?)").run("Dra. Ana Martínez");
}
if (!db.prepare("SELECT COUNT(*) c FROM rooms").get().c) {
  for (const n of ["Consultorio 1","Consultorio 2","Consultorio 3"])
    db.prepare("INSERT INTO rooms (name) VALUES (?)").run(n);
}

function broadcast(type="update") {
  const payload = `data: ${JSON.stringify({ type, at: Date.now() })}\n\n`;
  for (const res of clients) res.write(payload);
}
function nextNumber() {
  return db.prepare("SELECT COALESCE(MAX(number),0)+1 n FROM tickets").get().n;
}

app.get("/api/doctors", (_, res) =>
  res.json(db.prepare("SELECT * FROM doctors WHERE active=1 ORDER BY name").all())
);
app.get("/api/rooms", (_, res) =>
  res.json(db.prepare("SELECT * FROM rooms WHERE active=1 ORDER BY id").all())
);

app.get("/api/tickets", (_, res) => res.json(db.prepare(`
  SELECT t.id,t.number,t.patient,t.status,t.created_at,t.called_at,
         d.name doctor,r.name room
  FROM tickets t JOIN doctors d ON d.id=t.doctor_id JOIN rooms r ON r.id=t.room_id
  WHERE t.status IN ('waiting','called')
  ORDER BY CASE WHEN t.status='called' THEN 0 ELSE 1 END,t.id
`).all()));

app.get("/api/current", (_, res) => res.json(db.prepare(`
  SELECT t.id,t.number,t.patient,t.status,t.called_at,d.name doctor,r.name room
  FROM tickets t JOIN doctors d ON d.id=t.doctor_id JOIN rooms r ON r.id=t.room_id
  WHERE t.status='called' ORDER BY t.called_at DESC,t.id DESC LIMIT 1
`).get() || null));

app.post("/api/tickets", (req,res) => {
  const patient=String(req.body.patient||"").trim();
  const doctorId=Number(req.body.doctorId), roomId=Number(req.body.roomId);
  if(!patient||!doctorId||!roomId) return res.status(400).json({error:"Paciente, médico y consultorio son obligatorios."});
  const number=nextNumber();
  const result=db.prepare("INSERT INTO tickets(number,patient,doctor_id,room_id) VALUES(?,?,?,?)")
    .run(number,patient,doctorId,roomId);
  broadcast("ticket-created");
  res.json({id:result.lastInsertRowid,number});
});

app.post("/api/call-next", (_,res) => {
  const next=db.prepare("SELECT id FROM tickets WHERE status='waiting' ORDER BY id LIMIT 1").get();
  if(!next) return res.status(404).json({error:"No hay pacientes en espera."});
  db.prepare("UPDATE tickets SET status='called',called_at=datetime('now') WHERE status='called'").run();
  db.prepare("UPDATE tickets SET status='called',called_at=datetime('now') WHERE id=?").run(next.id);
  broadcast("call");
  res.json({ok:true});
});

app.post("/api/tickets/:id/recall",(req,res)=>{
  const id=Number(req.params.id);
  if(!db.prepare("SELECT id FROM tickets WHERE id=? AND status='called'").get(id))
    return res.status(404).json({error:"Turno no encontrado."});
  db.prepare("UPDATE tickets SET called_at=datetime('now') WHERE id=?").run(id);
  broadcast("recall");
  res.json({ok:true});
});

app.post("/api/tickets/:id/finish",(req,res)=>{
  const id=Number(req.params.id);
  db.prepare("UPDATE tickets SET status='finished' WHERE id=?").run(id);
  broadcast("finish");
  res.json({ok:true});
});

app.get("/api/stream",(req,res)=>{
  res.setHeader("Content-Type","text/event-stream");
  res.setHeader("Cache-Control","no-cache");
  res.setHeader("Connection","keep-alive");
  res.flushHeaders();
  res.write(`data: ${JSON.stringify({type:"connected",at:Date.now()})}\n\n`);
  clients.add(res);
  const heartbeat=setInterval(()=>res.write(": heartbeat\n\n"),15000);
  req.on("close",()=>{clearInterval(heartbeat);clients.delete(res);});
});

app.get("/tv",(req,res)=>res.sendFile(path.join(__dirname,"public","tv.html")));
app.get("/recepcion",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

app.listen(PORT,"0.0.0.0",()=>console.log(`Turnos Clínica V1.1: http://localhost:${PORT}`));
