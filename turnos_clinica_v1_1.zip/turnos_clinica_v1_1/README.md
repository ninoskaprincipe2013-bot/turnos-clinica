# Turnos Clínica — V1.1

## Cambios de esta versión
- Recepción y TV son pantallas separadas.
- URL `/recepcion` para recepción.
- URL `/tv` para el Smart TV.
- Comunicación en tiempo real mediante Server-Sent Events (SSE).
- La TV se actualiza inmediatamente al crear, llamar, repetir o finalizar un turno.
- Indicador de conexión en recepción.
- Diseño de TV optimizado para visualizarse a distancia.
- La llamada por voz se reproduce en la pantalla TV cuando cambia el turno.

## Instalación

Requiere Node.js 20+.

```bash
npm install
npm start
```

Recepción:
`http://localhost:3000/recepcion`

TV:
`http://IP-DEL-ORDENADOR:3000/tv`

Ejemplo:
`http://192.168.1.50:3000/tv`

El ordenador y el Smart TV deben estar en la misma red local.

## Próxima fase recomendada
Autenticación, administración de médicos/consultorios desde la interfaz, selección de prefijos (A/B/C), historial, múltiples pantallas, configuración de clínica y endurecimiento de seguridad/privacidad para producción.
